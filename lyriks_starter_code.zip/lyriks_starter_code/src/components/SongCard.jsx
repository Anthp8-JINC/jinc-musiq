const SongCard = () => (
  <div>SongCard</div>
);

export default SongCard;
